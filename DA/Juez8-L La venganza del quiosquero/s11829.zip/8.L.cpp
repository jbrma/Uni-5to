// gay el q lo lea

/*@ <answer>
 *
 * Nombre y Apellidos:
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


 // ================================================================
 // Escribe el código completo de tu solución aquí debajo
 // ================================================================
 //@ <answer>

bool resuelveCaso() {

    // leer los datos de la entrada
    long long int N, S;

    cin >> N;

    if (!std::cin)  // fin de la entrada
        return false;

    cin >> S;

    long long int mitad = S / 2;

    long long int s1, s2, s3, resul, resto, fin, max;

    s1 = mitad * (mitad + 1) / 2;
    s2 = S * (S + 1) / 2;
    fin = N - mitad;
    max = S + fin - 1;
    s3 = max * (max + 1) / 2;

    resto = s2 - s1 - S;

    resul = s3 - resto;

    cout << resul << '\n';

    return true;
}

int main() {
    // ajustes para que cin extraiga directamente de un fichero
//#ifndef DOMJUDGE
//    std::ifstream in("casos.txt");
//    auto cinbuf = std::cin.rdbuf(in.rdbuf());
//#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
//#ifndef DOMJUDGE
//    std::cin.rdbuf(cinbuf);
//    system("PAUSE");
//#endif
    return 0;
}
